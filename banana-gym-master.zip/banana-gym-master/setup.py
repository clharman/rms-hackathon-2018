#!/usr/bin/env python
from setuptools import setup

setup(name='gym_banana',
      version='0.0.1',
      install_requires=['gym>=0.2.3',
                        'pandas',
                        'cfg_load']
      )
